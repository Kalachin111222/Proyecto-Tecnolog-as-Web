<?php $__env->startSection('title', 'Resultados de búsqueda - D\'Ennita'); ?>
<?php $__env->startSection('contenido'); ?>

<main class="container py-5 flex-grow-1">
    <div class="mb-4">
        <h2 class="fw-bold" style="color:var(--text-primary);">Resultados para: "<?php echo e($query); ?>"</h2>
        <p class="text-muted">Se encontraron <?php echo e($productos->count()); ?> producto(s)</p>
    </div>

    <?php if($productos->count() > 0): ?>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="product-card h-100">
                    <a href="<?php echo e(route('producto', $producto->slug)); ?>" class="text-decoration-none">
                        <img src="<?php echo e(asset($producto->imagen)); ?>" alt="<?php echo e($producto->nombre); ?>" class="img-fluid mb-3 rounded" style="height: 180px; object-fit: contain; width: 100%;">
                        <h6 class="fw-bold text-dark text-truncate"><?php echo e($producto->nombre); ?></h6>
                    </a>
                    <div class="mt-auto d-flex justify-content-between align-items-center pt-3 border-top">
                        <span class="fs-5 fw-bold text-dark">S/ <?php echo e(number_format($producto->precio, 2)); ?></span>

                        
                        <form action="/carrito/items" method="POST" class="m-0">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="producto_id" value="<?php echo e($producto->id); ?>">
                            <input type="hidden" name="cantidad" value="1">
                            <button type="submit" class="btn-agregar" title="Agregar al carrito">
                                +
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <h1 style="font-size: 4rem;">🔍</h1>
            <h4 class="mt-3 text-muted">No encontramos productos que coincidan con tu búsqueda.</h4>
            <a href="<?php echo e(route('inicio')); ?>" class="btn btn-primary mt-3">Volver a la tienda</a>
        </div>
    <?php endif; ?>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/buscar.blade.php ENDPATH**/ ?>