<?php $__env->startSection('title', $titulo . " - D'Ennita"); ?>
<?php $__env->startSection('contenido'); ?>

<main class="p-3 flex-grow-1" style="background-color:var(--bg-secondary);">
    <div class="container-xl">

        
        <nav aria-label="breadcrumb" class="py-4">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('inicio')); ?>"
                       class="text-decoration-none fw-medium"
                       style="color:var(--text-secondary);"
                       data-translate="nav.home">Inicio</a>
                </li>
                <li class="breadcrumb-item active fw-semibold" aria-current="page"
                    style="color:var(--item-migas-activo);">
                    <?php echo e($titulo); ?>

                </li>
            </ol>
        </nav>

        <h2 class="fs-4 fw-semibold mb-4" style="color:var(--text-producto);"><?php echo e($titulo); ?></h2>

        
        <section class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6 g-3 mb-5">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="product-card h-100">
                    <a href="<?php echo e(route('producto', $producto->slug)); ?>" class="d-block">
                        <img src="<?php echo e(asset($producto->imagen)); ?>" alt="<?php echo e($producto->nombre); ?>"
                             class="w-100 mx-auto mb-2 object-fit-contain"
                             style="max-height:144px;transition:transform .3s;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'">
                    </a>
                    <a href="<?php echo e(route('producto', $producto->slug)); ?>" class="text-decoration-none flex-grow-1">
                        <p class="mb-0 text-start"
                           style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;color:var(--text-primary);">
                            <?php echo e($producto->nombre); ?>

                        </p>
                    </a>
                    <div class="d-flex align-items-center justify-content-between mt-2">
                        <span class="fw-bold" style="color:var(--text-primary);">S/ <?php echo e(number_format($producto->precio, 2)); ?></span>
                        <button class="btn-agregar" aria-label="Añadir"
                                data-producto-id="<?php echo e($producto->id); ?>">+</button>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/categoria.blade.php ENDPATH**/ ?>