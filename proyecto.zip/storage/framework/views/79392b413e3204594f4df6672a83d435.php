<?php $__env->startSection('contenido'); ?>
<div class="container py-5" style="max-width:960px;">
    <h1 class="fs-3 fw-bold text-center mb-5" style="color:var(--text-primary);">
        Integrantes
    </h1>

    <div class="row row-cols-1 g-4 justify-content-center">

        <div class="col">
            <div class="p-4 rounded-3 shadow-sm text-center" style="background-color:var(--bg-card);">
                <h2 class="fs-5 fw-semibold mb-0" style="color:var(--text-primary);">Aguilar Meza Yolver</h2>
            </div>
        </div>

        <div class="col">
            <div class="p-4 rounded-3 shadow-sm text-center" style="background-color:var(--bg-card);">
                <h2 class="fs-5 fw-semibold mb-0" style="color:var(--text-primary);">Arcos Arce Santiago</h2>
            </div>
        </div>

        <div class="col">
            <div class="p-4 rounded-3 shadow-sm text-center" style="background-color:var(--bg-card);">
                <h2 class="fs-5 fw-semibold mb-0" style="color:var(--text-primary);">Bernilla de la Cruz Jean</h2>
            </div>
        </div>

        <div class="col">
            <div class="p-4 rounded-3 shadow-sm text-center" style="background-color:var(--bg-card);">
                <h2 class="fs-5 fw-semibold mb-0" style="color:var(--text-primary);">Rebaza Castañeda Joseph</h2>
            </div>
        </div>

        <div class="col">
            <div class="p-4 rounded-3 shadow-sm text-center" style="background-color:var(--bg-card);">
                <h2 class="fs-5 fw-semibold mb-0" style="color:var(--text-primary);">Rodriguez Rubio Ray</h2>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/nosotros.blade.php ENDPATH**/ ?>