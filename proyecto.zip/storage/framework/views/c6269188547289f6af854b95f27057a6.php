<?php $__env->startSection('title', $producto->nombre . ' - D\'Ennita'); ?>
<?php $__env->startSection('contenido'); ?>

<main class="p-3 flex-grow-1" style="background-color:var(--bg-secondary);">
    <div class="container-xl">

        
        <nav aria-label="breadcrumb" class="py-4">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('inicio')); ?>"
                       class="text-decoration-none fw-medium"
                       style="color:var(--text-secondary);">Inicio</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route($producto->categoria)); ?>"
                       class="text-decoration-none fw-medium text-capitalize"
                       style="color:var(--text-secondary);"><?php echo e(ucfirst($producto->categoria)); ?></a>
                </li>
                <li class="breadcrumb-item active fw-semibold" aria-current="page"
                    style="color:var(--item-migas-activo);">
                    <?php echo e($producto->nombre); ?>

                </li>
            </ol>
        </nav>

        
        <div class="row g-5 mt-1 rounded-4 p-4 shadow-sm" style="background-color:var(--bg-card);">

            
            <div class="col-12 col-md-6 d-flex align-items-center justify-content-center">
                <img src="<?php echo e(asset($producto->imagen)); ?>" alt="<?php echo e($producto->nombre); ?>"
                     class="img-fluid rounded-3 object-fit-contain"
                     style="max-height:380px;">
            </div>

            
            <div class="col-12 col-md-6 d-flex flex-column justify-content-center gap-3">
                <h1 class="fs-4 fw-bold mb-0" style="color:var(--text-primary);"><?php echo e($producto->nombre); ?></h1>

                <p class="fs-3 fw-bold mb-0" style="color:var(--text-primary);">S/ <?php echo e(number_format($producto->precio, 2)); ?></p>

                <p class="lh-base mb-0" style="color:var(--text-secondary);"><?php echo e($producto->descripcion); ?></p>

                <button data-producto-id="<?php echo e($producto->id); ?>"
                onclick="agregarAlCarrito('<?php echo e(addslashes($producto->nombre)); ?>', <?php echo e($producto->precio); ?>, <?php echo e($producto->id); ?>, '<?php echo e(asset($producto->imagen)); ?>')"
                class="btn rounded-pill fw-bold text-black px-4 py-2 align-self-start"
                        style="background-color:var(--btnAgregar);transition:filter .2s;"
                        onmouseover="this.style.filter='brightness(.9)'"
                        onmouseout="this.style.filter='brightness(1)'">
                    + Agregar al carrito
                </button>
            </div>
        </div>

        
        <?php if($relacionados->count() > 0): ?>
        <div class="mt-5">
            <h2 class="fs-5 fw-semibold mb-4" style="color:var(--text-producto);">Podrían interesarte</h2>
            <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6 g-3">
                <?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e(route('producto', $rel->slug)); ?>" class="text-decoration-none">
                        <div class="product-card h-100"
                             style="transition:transform .3s;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'">
                            <img src="<?php echo e(asset($rel->imagen)); ?>" alt="<?php echo e($rel->nombre); ?>"
                                 class="w-100 mx-auto mb-2 object-fit-contain"
                                 style="max-height:144px;">
                            <p class="small text-start flex-grow-1 mb-0"
                               style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;color:var(--text-primary);">
                                <?php echo e($rel->nombre); ?>

                            </p>
                            <div class="d-flex align-items-center justify-content-between mt-2">
                                <span class="fw-bold small" style="color:var(--text-primary);">S/ <?php echo e(number_format($rel->precio, 2)); ?></span>
                                <button onclick="event.preventDefault(); agregarAlCarrito('<?php echo e(addslashes($rel->nombre)); ?>', <?php echo e($rel->precio); ?>, <?php echo e($rel->id); ?>)"
                                        data-producto-id="<?php echo e($rel->id); ?>"
                                        class="btn-agregar">+</button>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/producto.blade.php ENDPATH**/ ?>