<?php $__env->startSection('title', 'Admin - D\'Ennita'); ?>
<?php $__env->startSection('contenido'); ?>

<main class="p-3 flex-grow-1" style="background-color:var(--bg-secondary);">
    <div class="container-xl">
        <h1 class="fs-3 fw-bold mb-4" style="color:var(--text-primary);">Panel de Administración</h1>

        
        <ul class="nav nav-tabs mb-4" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#productos">📦 Productos</button>
            </li>
            <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#pedidos">📋 Pedidos</button>
            </li>
        </ul>

        <div class="tab-content">
            
            <div class="tab-pane fade show active" id="productos">
                <?php echo $__env->make('partials.admin-productos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            
            <div class="tab-pane fade" id="pedidos">
                <?php echo $__env->make('partials.admin-pedidos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/admin.blade.php ENDPATH**/ ?>