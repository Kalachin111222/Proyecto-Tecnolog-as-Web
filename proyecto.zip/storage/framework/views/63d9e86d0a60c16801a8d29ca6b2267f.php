
<div class="rounded-4 shadow-sm p-4 mb-5" style="background-color:var(--bg-card);">
    <h2 class="fs-6 fw-semibold mb-4" style="color:var(--text-primary);">Agregar nuevo producto</h2>
    <form method="POST" action="<?php echo e(route('moderador.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <input type="text" name="nombre" placeholder="Nombre del producto" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
            </div>
            <div class="col-12 col-md-6">
                <select name="categoria" required class="form-select rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
                    <option value="">Selecciona categoría</option>
                    <?php $__currentLoopData = ['cervezas','licores','comidas','bebidas','antojos','helados','despensa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat); ?>"><?php echo e(ucfirst($cat)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12 col-md-6">
                <input type="number" name="precio" step="0.01" min="0" placeholder="Precio (S/)" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
            </div>
            <div class="col-12 col-md-6">
                <input type="number" name="stock" min="0" placeholder="Stock (unidades)" required value="0" class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
            </div>
            <div class="col-12">
                <input type="text" name="imagen" placeholder="Ruta de imagen (ej: imagenes/Productos/foto.png)" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
            </div>
            <div class="col-12">
                <textarea name="descripcion" placeholder="Descripción del producto" rows="2" class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);"></textarea>
            </div>
            <div class="col-12">
                <button type="submit" class="btn w-100 fw-bold text-black rounded-3" style="background-color:var(--btnAgregar);transition:filter .2s;" onmouseover="this.style.filter='brightness(.9)'" onmouseout="this.style.filter='brightness(1)'">
                    Agregar producto
                </button>
            </div>
        </div>
    </form>
</div>


<div class="rounded-4 shadow-sm overflow-hidden" style="background-color:var(--bg-card);">
    <div class="table-responsive">
        <table class="table mb-0 small align-middle">
            <thead style="background-color:var(--bg-primary);">
                <tr>
                    <th class="p-3 text-start fw-medium" style="color:var(--text-secondary);">Imagen</th>
                    <th class="p-3 text-start fw-medium" style="color:var(--text-secondary);">Nombre</th>
                    <th class="p-3 text-start fw-medium" style="color:var(--text-secondary);">Categoría</th>
                    <th class="p-3 text-start fw-medium" style="color:var(--text-secondary);">Precio</th>
                    <th class="p-3 text-center fw-medium" style="color:var(--text-secondary);">Stock</th>
                    <th class="p-3 text-center fw-medium" style="color:var(--text-secondary);">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-top:1px solid var(--border-color);" id="fila-<?php echo e($producto->id); ?>">
                    <td class="p-3">
                        <img src="<?php echo e(asset($producto->imagen)); ?>" alt="<?php echo e($producto->nombre); ?>" class="rounded-2 object-fit-contain" style="width:56px;height:56px;">
                    </td>
                    <td class="p-3" style="color:var(--text-primary);"><?php echo e($producto->nombre); ?></td>
                    <td class="p-3 text-capitalize" style="color:var(--text-secondary);"><?php echo e($producto->categoria); ?></td>
                    <td class="p-3 fw-bold" style="color:var(--text-primary);">S/ <?php echo e(number_format($producto->precio, 2)); ?></td>
                    <td class="p-3 text-center">
                        <?php if($producto->stock === 0): ?>
                            <span class="badge rounded-pill text-bg-danger">Sin stock</span>
                        <?php elseif($producto->stock <= 5): ?>
                            <span class="badge rounded-pill text-bg-warning"><?php echo e($producto->stock); ?> uds.</span>
                        <?php else: ?>
                            <span class="badge rounded-pill text-bg-success"><?php echo e($producto->stock); ?> uds.</span>
                        <?php endif; ?>
                    </td>
                    <td class="p-3 text-center">
                        <div class="d-flex gap-2 justify-content-center">
                            <button onclick="abrirEditar(<?php echo e($producto->id); ?>, '<?php echo e(addslashes($producto->nombre)); ?>', '<?php echo e($producto->categoria); ?>', <?php echo e($producto->precio); ?>, <?php echo e($producto->stock); ?>, '<?php echo e(addslashes($producto->imagen)); ?>', '<?php echo e(addslashes($producto->descripcion)); ?>')"
                                    class="btn btn-sm btn-primary fw-semibold">Editar</button>
                            <form method="POST" action="<?php echo e(route('moderador.destroy', $producto->id)); ?>" onsubmit="return confirm('¿Eliminar este producto?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger fw-semibold">Eliminar</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<div class="modal fade" id="modal-editar" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 shadow border-0" style="background-color:var(--bg-card);">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-semibold" id="modalEditarLabel" style="color:var(--text-primary);">Editar producto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body pt-3">
                <form id="form-editar" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <div class="d-flex flex-column gap-3">
                        <input type="text" name="nombre" id="edit-nombre" placeholder="Nombre" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
                        <select name="categoria" id="edit-categoria" required class="form-select rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
                            <?php $__currentLoopData = ['cervezas','licores','comidas','bebidas','antojos','helados','despensa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat); ?>"><?php echo e(ucfirst($cat)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="row g-3">
                            <div class="col"><input type="number" name="precio" id="edit-precio" step="0.01" min="0" placeholder="Precio (S/)" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);"></div>
                            <div class="col"><input type="number" name="stock" id="edit-stock" min="0" placeholder="Stock" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);"></div>
                        </div>
                        <input type="text" name="imagen" id="edit-imagen" placeholder="Ruta imagen" required class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);">
                        <textarea name="descripcion" id="edit-descripcion" rows="2" placeholder="Descripción" class="form-control rounded-3" style="background:var(--bg-primary);color:var(--text-primary);border-color:var(--border-color);"></textarea>
                        <button type="submit" class="btn w-100 fw-bold text-black rounded-3" style="background-color:var(--btnAgregar);transition:filter .2s;" onmouseover="this.style.filter='brightness(.9)'" onmouseout="this.style.filter='brightness(1)'">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function abrirEditar(id, nombre, categoria, precio, stock, imagen, descripcion) {
    document.getElementById('form-editar').action = '/moderador/productos/' + id;
    document.getElementById('edit-nombre').value      = nombre;
    document.getElementById('edit-categoria').value   = categoria;
    document.getElementById('edit-precio').value      = precio;
    document.getElementById('edit-stock').value       = stock;
    document.getElementById('edit-imagen').value      = imagen;
    document.getElementById('edit-descripcion').value = descripcion;
    new bootstrap.Modal(document.getElementById('modal-editar')).show();
}
</script>
<?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/partials/admin-productos.blade.php ENDPATH**/ ?>