<div class="table-responsive bg-white p-4 rounded shadow-sm">
    <table class="table align-middle">
        <thead>
            <tr>
                <th>Código</th>
                <th>Cliente</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pedido->codigo_pedido); ?></td>
                <td><?php echo e($pedido->user->usuario ?? 'N/A'); ?></td>
                <td>S/ <?php echo e(number_format($pedido->total, 2)); ?></td>
                <td>
                    <form action="<?php echo e(route('admin.pedidos.estado', $pedido->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <select name="estado" onchange="this.form.submit()" class="form-select form-select-sm <?php echo e($pedido->estado == 'pagado' ? 'bg-success text-white' : 'bg-warning'); ?>">
                            <option value="pendiente" <?php echo e($pedido->estado == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                            <option value="pagado" <?php echo e($pedido->estado == 'pagado' ? 'selected' : ''); ?>>Pagado</option>
                            <option value="preparando" <?php echo e($pedido->estado == 'preparando' ? 'selected' : ''); ?>>Preparando</option>
                            <option value="enviado" <?php echo e($pedido->estado == 'enviado' ? 'selected' : ''); ?>>Enviado</option>
                            <option value="entregado" <?php echo e($pedido->estado == 'entregado' ? 'selected' : ''); ?>>Entregado</option>
                            <option value="cancelado" <?php echo e($pedido->estado == 'cancelado' ? 'selected' : ''); ?>>Cancelado</option>
                        </select>
                    </form>
                </td>
                <td>
                    <a href="<?php echo e(route('boleta', $pedido->codigo_pedido)); ?>" class="btn btn-sm btn-info">Ver Boleta</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/arzeuz/Documents/UNI/V/TW/Proyecto/Proyecto-Tecnolog-as-Web/resources/views/partials/admin-pedidos.blade.php ENDPATH**/ ?>