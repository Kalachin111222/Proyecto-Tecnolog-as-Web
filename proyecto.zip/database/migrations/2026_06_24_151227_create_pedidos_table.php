<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pedidos', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
        $table->string('codigo_pedido')->unique(); // Ej: PED-0001
        $table->decimal('total', 10, 2);
        $table->enum('estado', ['pendiente', 'pagado', 'preparando', 'enviado', 'entregado', 'cancelado'])->default('pendiente');
        $table->string('metodo_pago')->nullable(); // Ej: Yape, Efectivo, Tarjeta
        $table->text('direccion_envio')->nullable();
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pedidos');
    }
};
